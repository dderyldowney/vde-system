#!/bin/bash
set -e

# Base directory
BASE_DIR="$HOME/dev"

# Ensure Docker network exists
docker network inspect dev-net >/dev/null 2>&1 || docker network create dev-net

# Function to build and start a service
start_service() {
    local service_dir="$1"
    echo "Building and starting service in $service_dir..."
    cd "$service_dir"
    docker-compose build
    docker-compose up -d
}

# Start Postgres VM
start_service "$BASE_DIR/configs/docker/postgres"

# Start Python VM
start_service "$BASE_DIR/configs/docker/python"

# Start Rust VM
start_service "$BASE_DIR/configs/docker/rust"

# Start JavaScript VM
start_service "$BASE_DIR/configs/docker/javascript"

echo
echo "All containers are up and running!"
echo "SSH access:"
echo "  Python VM:   ssh -p 2222 devuser@localhost"
echo "  Rust VM:     ssh -p 2223 devuser@localhost"
echo "  JavaScript VM: ssh -p 2224 devuser@localhost"
echo "  Postgres VM: ssh -p 2225 devuser@localhost"
echo
echo "Language VMs connect to Postgres using devuser:SuperSecretPassword123! and the respective databases:"
echo "  python_dev_db, rust_dev_db, js_dev_db"
